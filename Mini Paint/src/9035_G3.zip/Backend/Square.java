/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Map;

/**
 *
 * @author Omar Fayed
 */
public class Square extends AbstractShape {
    private int length;
    public Square(Point position, Color color, Color fillColor, Map<String, Double> properties) {
        super(position, color, fillColor, properties);
        this.length = properties.get("L").intValue();
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    void draw(Canvas canvas) {
        Graphics g = canvas.getGraphics();
        g.setColor(this.getColor());
        g.drawRect(this.getPosition().getX(), this.getPosition().getY(), length, length);
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(this.getFillColor());
        g2.fillRect(this.getPosition().getX(), this.getPosition().getY(), length, length);
    }

    
    
}
