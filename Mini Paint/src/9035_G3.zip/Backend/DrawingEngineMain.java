/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import java.util.ArrayList;

/**
 *
 * @author Omar Fayed
 */
public class DrawingEngineMain implements DrawingEngine {
    private ArrayList<Shape> shapes = new ArrayList<Shape>();

   
    
    public void addShape(Shape shape) {
        shapes.add(shape);
        System.out.println("Shape added");
    }
    
    
    @Override
    public void removeShape(Shape shape) {
        shapes.remove(shape);
        System.out.println("Shape removed");
    }
    
    @Override
    public Shape[] getShapes() {
        Shape[] shapes_arr = null;
        int count = 0;
        for (Shape i : shapes) {
            shapes_arr[count] = i;
            count++;
        }
        return shapes_arr;
    }
    
    @Override
    public void refresh(java.awt.Canvas canvas) {
        for (Shape i : shapes) {
            i.draw(canvas);
        }
        System.out.println("Refreshed");
    }
    
}
