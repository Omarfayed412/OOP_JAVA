/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Map;

/**
 *
 * @author Omar Fayed
 */
public class Line extends AbstractShape {
    private Point endingPoint;

    public Line(Point position, Color color, Color fillColor, Map<String, Double> properties) {
        super(position, color, fillColor, properties);
        this.endingPoint.setX(properties.get("X").intValue());
        this.endingPoint.setY(properties.get("Y").intValue());        
    }

    public Point getEndingPoint() {
        return endingPoint;
    }

    @Override
    void draw(Canvas canvas) {
        Graphics g = canvas.getGraphics();
        g.setColor(this.getColor());
        g.drawLine(this.getPosition().getX(), this.getPosition().getY(), endingPoint.getX(), endingPoint.getY());
    }
    
}
